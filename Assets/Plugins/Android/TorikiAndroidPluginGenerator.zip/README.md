# CO2

CO2 is Android Plugin build tool for Unity.

## usage

locate android module into project/ModuleContainedProject folder,  
then run 

	sh build.sh



## example

this "project" folder contains the base project(ModuleContainedProject).  
current build target module is, "urlschemeplugin" module inside the ModuleContainedProject folder.

run 

	sh build.sh 

will generate Android plugin .aar file into the "project" folder.