package com.twitter.sdk.android.core;

public class TwitterError {
    /**
     * Unknown error.
     */
    public static final int TKLogInErrorCodeUnknown = -1;

    /**
     * User denied login.
     */
    public static final int TKLogInErrorCodeDenied = 0;

    /**
     * User canceled login.
     */
    public static final int TKLogInErrorCodeCancelled = 1;

    /**
     * No Twitter account found.
     */
    public static final int TKLogInErrorCodeNoAccounts = 2;

    /**
     * Reverse auth with linked account failed.
     */
    public static final int TKLogInErrorCodeReverseAuthFailed = 3;

    /**
     *  Refreshing session tokens failed.
     */
    public static final int TKLogInErrorCodeCannotRefreshSession = 4;

    /**
     *  No such session or session is not tracked
     *  in the associated session store.
     */
    public static final int TKLogInErrorCodeSessionNotFound = 5;

    /**
     * The login request failed.
     */
    public static final int TKLogInErrorCodeFailed = 6;

    /**
     * The system account credentials are no longer valid and the
     * user will need to update their credentials in the Settings app.
     */
    public static final int TKLogInErrorCodeSystemAccountCredentialsInvalid = 7;

    /**
     *  There was no Twitter Android app installed to attemp
     *  the Mobile SSO flow.
     */
    public static final int TKLoginErrorNoTwitterApp = 8;
}