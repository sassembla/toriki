package com.twitter.sdk.android.core;
public class Callback {
    public void success(String token, String secret, String screenName) {}
    public void failure(int code, String message) {}
}
