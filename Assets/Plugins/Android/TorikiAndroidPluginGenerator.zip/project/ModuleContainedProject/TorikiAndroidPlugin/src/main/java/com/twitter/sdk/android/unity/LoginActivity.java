/*
    呼び出されるコード
*/
package com.twitter.sdk.android.unity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.identity.TwitterAuthClient;

import com.unity3d.player.UnityPlayer;

// ログインに使用するアクティビティ
public class LoginActivity extends Activity {
    TwitterAuthClient authClient;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        authClient = new TwitterAuthClient();
        authClient.authorize(this, new Callback() {            
            public void success(String token, String secret, String screenName) {
                final String session = "{\"nickname\":\"" + screenName + "\", \"accessToken\":\"" + token + "\", \"accessSecret\":\"" + secret + "\"}";
                UnityPlayer.UnitySendMessage(TwitterKit.GAME_OBJECT_NAME, "LoginComplete", session);
                finish();
            }

            public void failure(int code, String message) {
                final String error = "{\"code\":\"" + code + "\", \"message\":\"" + message + "\"}";
                UnityPlayer.UnitySendMessage(TwitterKit.GAME_OBJECT_NAME, "LoginFailed", error);
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        authClient.onActivityResult(requestCode, resultCode, data);
    }
}
