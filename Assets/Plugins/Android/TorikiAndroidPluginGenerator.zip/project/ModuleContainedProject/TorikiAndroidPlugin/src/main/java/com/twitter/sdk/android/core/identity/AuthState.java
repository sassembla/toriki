package com.twitter.sdk.android.core.identity;

import android.app.Activity;

import com.twitter.sdk.android.core.Twitter;
import java.util.concurrent.atomic.AtomicReference;


class AuthState {

    final AtomicReference<AuthHandler> authHandlerRef = new AtomicReference<>(null);

    public boolean beginAuthorize(Activity activity, AuthHandler authHandler) {
        boolean result = false;
        if (isAuthorizeInProgress()) {
            // do nothing.
        } else if (authHandler.authorize(activity)) {
            result = authHandlerRef.compareAndSet(null, authHandler);
            if (!result) {
                // do nothing.
            }
        }
        return result;
    }

    public void endAuthorize() {
        authHandlerRef.set(null);
    }

    public boolean isAuthorizeInProgress() {
        return authHandlerRef.get() != null;
    }

    public AuthHandler getAuthHandler() {
        return authHandlerRef.get();
    }
}
