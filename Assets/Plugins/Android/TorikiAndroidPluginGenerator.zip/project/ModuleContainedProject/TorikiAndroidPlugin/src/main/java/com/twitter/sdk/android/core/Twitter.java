package com.twitter.sdk.android.core;

import android.annotation.SuppressLint;
import android.content.Context;

import java.io.File;
import java.util.concurrent.ExecutorService;

public class Twitter {
    public static final String TAG = "Twitter";
    private static final String CONSUMER_KEY = "com.twitter.sdk.android.CONSUMER_KEY";
    private static final String CONSUMER_SECRET = "com.twitter.sdk.android.CONSUMER_SECRET";
    private static final String NOT_INITIALIZED_MESSAGE = "Must initialize Twitter before using getInstance()";
    
    @SuppressLint("StaticFieldLeak")
    static volatile Twitter instance;

    private final Context context;
    private final TwitterAuthConfig twitterAuthConfig;
    
    private Twitter(TwitterConfig config) {
        context = config.context;
        twitterAuthConfig = config.twitterAuthConfig;
    }

    // これが使われてる
    public static void initialize(TwitterConfig config) {
        // インスタンスを生成してるが保持はしてない。
        createTwitter(config);
    }

    static synchronized Twitter createTwitter(TwitterConfig config) {
        if (instance == null) {
            instance = new Twitter(config);
            return instance;
        }

        return instance;
    }
}
