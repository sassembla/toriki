package com.twitter.sdk.android.core.identity;

import android.app.Activity;
import android.content.Intent;

import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterError;


public class TwitterAuthClient {

    private static class AuthStateLazyHolder {
        private static final AuthState INSTANCE = new AuthState();
    }

    final AuthState authState;

    public TwitterAuthClient() {
        this.authState = AuthStateLazyHolder.INSTANCE;
    }

    public void authorize(Activity activity, Callback callback) {
        System.out.println("TwitterAuthClient authorize");
        if (activity == null) {
            throw new IllegalArgumentException("Activity must not be null.");
        }
        if (callback == null) {
            throw new IllegalArgumentException("Callback must not be null.");
        }

        if (activity.isFinishing()) {

        } else {
            handleAuthorize(activity, callback);
        }
    }

    private void handleAuthorize(Activity activity, Callback callback) {
        final CallbackWrapper callbackWrapper = new CallbackWrapper(callback);
        if (authorizeUsingSSO(activity, callbackWrapper)) {
            return;
        }

        callbackWrapper.failure(TwitterError.TKLoginErrorNoTwitterApp, "no twitter app installed. please install twitter app first.");
    }

    public void cancelAuthorize() {
        authState.endAuthorize();
    }

    private boolean authorizeUsingSSO(Activity activity, CallbackWrapper callbackWrapper) {
        if (SSOAuthHandler.isAvailable(activity)) {
            return authState.beginAuthorize(
                activity,
                new SSOAuthHandler(callbackWrapper, 
                TwitterAuthConfig.DEFAULT_AUTH_REQUEST_CODE)
            );
        } else {
            return false;
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (!authState.isAuthorizeInProgress()) {
        } else {
            final AuthHandler authHandler = authState.getAuthHandler();
            if (authHandler != null &&
                    authHandler.handleOnActivityResult(requestCode, resultCode, data)) {
                authState.endAuthorize();
            }
        }
    }

    static class CallbackWrapper extends Callback {
        private final Callback callback;

        CallbackWrapper(Callback callback) {
            this.callback = callback;
        }

        public void success(String token, String secret, String screenName) {// Resultだったのを変更
            callback.success(token, secret, screenName);
        }

        public void failure(int code, String message) {
            callback.failure(code, message);
        }
    }
}
