/*
    起動クラス
*/
package com.twitter.sdk.android.unity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterConfig;
import com.unity3d.player.UnityPlayer;

public class TwitterKit {
    public static final String GAME_OBJECT_NAME = "TorikiGameObject";

    // 初期化
    public static void init(final String consumerKey, final String consumerSecret) {
        final TwitterConfig config = new TwitterConfig.Builder(
                UnityPlayer.currentActivity.getApplicationContext())
                .twitterAuthConfig(new TwitterAuthConfig(consumerKey, consumerSecret))
                .build();

        Twitter.initialize(config);
    }


    // ログインに使用するメソッド、単にログインが呼べればOK
    public static void login() {
        final Activity currentActivity = UnityPlayer.currentActivity;
        final Intent intent = new Intent(currentActivity, LoginActivity.class);
        currentActivity.startActivity(intent);
    }
}
