package com.twitter.sdk.android.core;

import android.os.Parcel;
import android.os.Parcelable;

public class TwitterAuthConfig implements Parcelable {

    public static final int DEFAULT_AUTH_REQUEST_CODE = 140;

    public static final Parcelable.Creator<TwitterAuthConfig> CREATOR
            = new Parcelable.Creator<TwitterAuthConfig>() {
        public TwitterAuthConfig createFromParcel(Parcel in) {
            return new TwitterAuthConfig(in);
        }

        public TwitterAuthConfig[] newArray(int size) {
            return new TwitterAuthConfig[size];
        }
    };

    public static String consumerKey;
    public static String consumerSecret;

    public TwitterAuthConfig(String consumerKey, String consumerSecret) {
        if (consumerKey == null || consumerSecret == null) {
            throw new IllegalArgumentException(
                    "TwitterAuthConfig must not be created with null consumer key or secret.");
        }

        this.consumerKey = sanitizeAttribute(consumerKey);
        this.consumerSecret = sanitizeAttribute(consumerSecret);
    }

    private TwitterAuthConfig(Parcel in) {
        consumerKey = in.readString();
        consumerSecret = in.readString();
    }

    /**
     * @return the consumer key
     */
    public String getConsumerKey() {
        return consumerKey;
    }

    /**
     * @return the consumer secret
     */
    public String getConsumerSecret() {
        return consumerSecret;
    }

    static String sanitizeAttribute(String input) {
        if (input != null) {
            return input.trim();
        } else {
            return null;
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(consumerKey);
        out.writeString(consumerSecret);
    }
}
