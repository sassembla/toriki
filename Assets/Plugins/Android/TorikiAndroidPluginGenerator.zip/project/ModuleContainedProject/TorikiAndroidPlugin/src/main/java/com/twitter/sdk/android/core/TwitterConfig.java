package com.twitter.sdk.android.core;

import android.content.Context;

import java.util.concurrent.ExecutorService;
import com.twitter.sdk.android.core.TwitterAuthConfig;

public class TwitterConfig {
    final Context context;
    final TwitterAuthConfig twitterAuthConfig;
    
    private TwitterConfig(Context context, TwitterAuthConfig twitterAuthConfig) {
        this.context = context;
        this.twitterAuthConfig = twitterAuthConfig;
    }

    public static class Builder {
        private final Context context;
        private TwitterAuthConfig twitterAuthConfig;
    
        public Builder(Context context) {
            if (context == null) {
                throw new IllegalArgumentException("Context must not be null.");
            }

            this.context = context.getApplicationContext();
        }

        public Builder twitterAuthConfig(TwitterAuthConfig authConfig) {
            if (authConfig == null) {
                throw new IllegalArgumentException("TwitterAuthConfig must not be null.");
            }

            this.twitterAuthConfig = authConfig;

            return this;
        }

        public TwitterConfig build() {
            return new TwitterConfig(context, twitterAuthConfig);
        }
    }
}
