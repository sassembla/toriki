
package com.twitter.sdk.android.core.identity;

import android.app.Activity;
import android.content.Intent;

import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.TwitterError;

public abstract class AuthHandler {
    static final String EXTRA_TOKEN = "tk";
    static final String EXTRA_TOKEN_SECRET = "ts";
    static final String EXTRA_SCREEN_NAME = "screen_name";
    static final String EXTRA_USER_ID = "user_id";
    static final String EXTRA_AUTH_ERROR = "auth_error";

    static final int RESULT_CODE_ERROR = Activity.RESULT_FIRST_USER;

    protected final int requestCode;
    private final Callback callback;

    AuthHandler(Callback callback, int requestCode) {
        this.callback = callback;
        this.requestCode = requestCode;
    }

    Callback getCallback() {
        return callback;
    }

    public abstract boolean authorize(Activity activity);

    public boolean handleOnActivityResult(int requestCode, int resultCode, Intent data) {
        if (this.requestCode != requestCode) {
            return false;
        }

        final Callback callback = getCallback();
        if (callback != null) {
            if (resultCode == Activity.RESULT_OK) {

                final String token = data.getStringExtra(EXTRA_TOKEN);
                final String tokenSecret = data.getStringExtra(EXTRA_TOKEN_SECRET);
                final String screenName = data.getStringExtra(EXTRA_SCREEN_NAME);
                final long userId = data.getLongExtra(EXTRA_USER_ID, 0L);

                callback.success(token, tokenSecret, screenName);
            } else if (data != null && data.hasExtra(EXTRA_AUTH_ERROR)) {
                callback.failure(TwitterError.TKLogInErrorCodeFailed, data.getSerializableExtra(EXTRA_AUTH_ERROR).toString());
            } else {
                callback.failure(TwitterError.TKLogInErrorCodeCancelled, "User cancelled.");
            }
        }
        return true;
    }
}
